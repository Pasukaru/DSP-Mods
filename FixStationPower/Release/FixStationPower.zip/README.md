﻿
# FixStationPower

[![GitHub](https://img.shields.io/github/license/pasukaru/DSP-Mods?style=for-the-badge)](https://github.com/Pasukaru/DSP-Mods/tree/main/FixStationPower)

## Features
Fixes station power that got broken with latest DSP version. Fix will execute after loading a save.

## Changelog

### 1.0.0
Initial Release
