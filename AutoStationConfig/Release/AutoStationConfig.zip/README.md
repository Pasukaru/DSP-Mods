﻿# AutoStationConfig

This mod automatically configures ILS when they are placed. 
Currently, the mod itself is not configurable.

This mod is intended for faster scaling of your production lines in end-game.

ILS will be setup like this:

Last item slot: <br>
Space Warper | 100 | Local Demand | Remote Storage

Max Charging Power set to max. <br>
Transport Range of Drones & Vessels set to max. <br>
Distance to enable warp: 0.5 AU. <br>
Min Load of Drones & Vessels: 100% <br>

It will also automatically insert max drones and vessels from your inventory into the station.
